import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../views/Home/Home.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/my',
    name: 'My',
    component:()=>import("@/views/My/My.vue")
  },
  {
    path: '/ranking',
    name: 'Ranking',
    component:()=>import("@/views/Ranking/Ranking.vue")
  },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
