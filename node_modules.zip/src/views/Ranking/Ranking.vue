<template>
    <div>
        我是榜单
        <TabBar></TabBar>
    </div>
</template>
<script setup>
import TabBar from "@/components/TabBar/TabBar.vue"
</script>
<style lang="scss" scoped>
</style>

